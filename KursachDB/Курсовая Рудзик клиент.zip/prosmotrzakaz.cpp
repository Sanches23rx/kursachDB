#include "prosmotrzakaz.h"
#include "ui_prosmotrzakaz.h"

prosmotrZakaz::prosmotrZakaz(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::prosmotrZakaz)
{
    ui->setupUi(this);
    setWindowTitle("Заказы");
}

prosmotrZakaz::~prosmotrZakaz()
{
    delete ui;
}

void prosmotrZakaz::on_pushButton_clicked()
{
    model2 = new QSqlQueryModel();
    model2 -> setQuery("SELECT Naimenovanie, Budjet, (SELECT Name FROM RecZak WHERE ID_zakazchika_Zakaz = ID_zakazchika) FROM Zakaz");

   // model2->setHeaderData(0, Qt::Horizontal, "ID заказа");
    model2->setHeaderData(0, Qt::Horizontal, "Наименование");
    model2->setHeaderData(1, Qt::Horizontal, "Бюджет");
    model2->setHeaderData(2, Qt::Horizontal, "Имя заказчика");

    ui->tableView->setModel(model2);
    ui->tableView->resizeColumnsToContents();
    ui->tableView->show();
}


void prosmotrZakaz::on_pushButton_2_clicked()
{
    model22 = new QSqlQueryModel();
    model22 -> setQuery("EXEC get_zakaz_by_namezakazchik @n = " + ui->lineEdit->text());


    model22->setHeaderData(0, Qt::Horizontal, "Имя заказчика");
    model22->setHeaderData(1, Qt::Horizontal, "Номер телефона");
    model22->setHeaderData(2, Qt::Horizontal, "Наименование");
    model22->setHeaderData(3, Qt::Horizontal, "Бюджет");
    model22->setHeaderData(4, Qt::Horizontal, "Статус");


    ui->tableView->setModel(model22);
    ui->tableView->resizeColumnsToContents();
    ui->tableView->show();
}


void prosmotrZakaz::on_pushButton_3_clicked()
{
    model23 = new QSqlQueryModel();
    model23 -> setQuery("EXEC get_zakaz_by_naimenovanie @e = " + ui->lineEdit_2->text());

    model23->setHeaderData(0, Qt::Horizontal, "Наименование");
    model23->setHeaderData(1, Qt::Horizontal, "Бюджет");

    ui->tableView->setModel(model23);
    ui->tableView->resizeColumnsToContents();
    ui->tableView->show();
}

