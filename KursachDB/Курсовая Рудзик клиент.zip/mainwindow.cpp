#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    setWindowTitle("Курсовая");
}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_actionconnect_to_DB_triggered()
{
    logwin=new login();
    logwin->show();
}


void MainWindow::on_action_2_triggered()
{
    prosIspolnit = new prosmotrIspolnit();
    prosIspolnit->show();

}


void MainWindow::on_action_3_triggered()
{
    prosZakaz = new prosmotrZakaz();
    prosZakaz->show();
}


void MainWindow::on_action_triggered()
{
    prosZakazchik =new ProsmotrZakazchika();
    prosZakazchik->show();
}


void MainWindow::on_action_4_triggered()
{
    addDogo = new AddDogovor();
    addDogo->show();
}


void MainWindow::on_action_7_triggered()
{
    prosDogo = new prosmotrdogovor();
    prosDogo->show();
}





void MainWindow::on_action_9_triggered()
{
    addSme = new addSmeta();
    addSme->show();
}


void MainWindow::on_action_10_triggered()
{
    addzak = new addzakazchik();
    addzak->show();
}


void MainWindow::on_action_11_triggered()
{
    addisp = new addispolnitel();
    addisp->show();
}


void MainWindow::on_action_12_triggered()
{
    addzaka = new addzakaz();
    addzaka->show();
}

