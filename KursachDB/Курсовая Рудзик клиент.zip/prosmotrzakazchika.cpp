#include "prosmotrzakazchika.h"
#include "ui_prosmotrzakazchika.h"

ProsmotrZakazchika::ProsmotrZakazchika(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ProsmotrZakazchika)
{
    ui->setupUi(this);
    setWindowTitle("Заказчики");
}

ProsmotrZakazchika::~ProsmotrZakazchika()
{
    delete ui;
}

void ProsmotrZakazchika::on_pushButton_clicked()
{
    model3 = new QSqlQueryModel();
    model3 -> setQuery("SELECT Name, Adres, phone FROM RecZak");

    //model3->setHeaderData(0, Qt::Horizontal, "ID_Заказчика");
    model3->setHeaderData(0, Qt::Horizontal, "Имя");
    model3->setHeaderData(1, Qt::Horizontal, "Адрес");
    model3->setHeaderData(2, Qt::Horizontal, "Телефон");

    ui->tableView->setModel(model3);
    ui->tableView->resizeColumnsToContents();
    ui->tableView->show();
}


void ProsmotrZakazchika::on_pushButton_2_clicked()
{
    model31 = new QSqlQueryModel();
    model31 -> setQuery("EXEC zakazov_bolsche_odnogo @p = " + ui->lineEdit->text());


    model31->setHeaderData(0, Qt::Horizontal, "Имя");
    model31->setHeaderData(1, Qt::Horizontal, "Адрес");
    model31->setHeaderData(2, Qt::Horizontal, "Телефон");


    ui->tableView->setModel(model31);
    ui->tableView->resizeColumnsToContents();
    ui->tableView->show();
}


void ProsmotrZakazchika::on_pushButton_3_clicked()
{
    model32 = new QSqlQueryModel();
    model32 -> setQuery("EXEC get_zakazchik_by_namezakazchik @gzn = " + ui->lineEdit_2->text());


    model32->setHeaderData(0, Qt::Horizontal, "Имя");
    model32->setHeaderData(1, Qt::Horizontal, "Адрес");
    model32->setHeaderData(2, Qt::Horizontal, "Телефон");


    ui->tableView->setModel(model32);
    ui->tableView->resizeColumnsToContents();
    ui->tableView->show();
}

