#ifndef ADDISPOLNITEL_H
#define ADDISPOLNITEL_H

#include <QWidget>
#include <QSqlQuery>
#include <QMessageBox>
#include <QSqlQueryModel>
#include <QSqlTableModel>

namespace Ui {
class addispolnitel;
}

class addispolnitel : public QWidget
{
    Q_OBJECT

public:
    explicit addispolnitel(QWidget *parent = nullptr);
    ~addispolnitel();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_tableView_clicked(const QModelIndex &index);

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

private:
    Ui::addispolnitel *ui;
    QSqlQueryModel*model1;
    QSqlDatabase db;

};

#endif // ADDISPOLNITEL_H
