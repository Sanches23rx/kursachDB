#ifndef ADDDOGOVOR_H
#define ADDDOGOVOR_H

#include <QWidget>
#include <QSqlQuery>
#include <QMessageBox>
#include <QSqlQueryModel>


namespace Ui {
class AddDogovor;
}

class AddDogovor : public QWidget
{
    Q_OBJECT

public:
    explicit AddDogovor(QWidget *parent = nullptr);
    ~AddDogovor();

    int zakcombo;
    int ispcombo;
    int zakazcombo;

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_13_clicked();

    void on_pushButton_14_clicked();

    void on_pushButton_15_clicked();

    void on_pushButton_16_clicked();

    void on_tableView_clicked(const QModelIndex &index);

    void on_pushButton_11_clicked();

    void on_pushButton_12_clicked();

    void on_comboBox_currentIndexChanged(int index);

    void on_comboBox_2_currentIndexChanged(int index);

    void on_comboBox_3_currentIndexChanged(int index);

private:
    Ui::AddDogovor *ui;
    QSqlDatabase db;
    QSqlQueryModel*model3;
    QSqlQueryModel*model1;
    QSqlQueryModel*model2;
    QSqlQueryModel*model5;

};

#endif // ADDDOGOVOR_H
