#ifndef PROSMOTRDOGOVOR_H
#define PROSMOTRDOGOVOR_H

#include <QWidget>
#include <QtSql>

namespace Ui {
class prosmotrdogovor;
}

class prosmotrdogovor : public QWidget
{
    Q_OBJECT

public:
    explicit prosmotrdogovor(QWidget *parent = nullptr);
    ~prosmotrdogovor();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

private:
    Ui::prosmotrdogovor *ui;
    QSqlDatabase db;
    QSqlQueryModel*model5;
    QSqlQueryModel*model51;
    QSqlQueryModel*model52;
    QSqlQueryModel*model53;

};

#endif // PROSMOTRDOGOVOR_H
