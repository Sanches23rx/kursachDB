#include "addsmeta.h"
#include "ui_addsmeta.h"

addSmeta::addSmeta(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::addSmeta)
{
    ui->setupUi(this);

    QSqlQuery* query9 = new QSqlQuery();

    query9->exec("SELECT NazvDogo FROM RecDogo");
    while(query9->next())
        {
            ui->comboBox->addItem(query9->value(0).toString());
        }
    smetcombo = 0;
}

addSmeta::~addSmeta()
{
    delete ui;
}

void addSmeta::on_pushButton_clicked()
{
    QSqlQuery* addSmeta = new QSqlQuery;

    addSmeta->prepare("EXEC add_smeta @svd = " + ui->lineEdit_2->text() + ", @rdnd = " + ui->comboBox->itemText(smetcombo) + ", @ssm = " + ui->lineEdit_3->text() + ", @sz = " + ui->lineEdit_4->text() + ", @sb = " + ui->lineEdit_5->text());

    QMessageBox* mess7 = new QMessageBox();

    if (!addSmeta->exec())
    {
        mess7->setText("Неправильно заполнена смета");
        mess7->show();
    }
}


void addSmeta::on_pushButton_2_clicked()
{
    model7 = new QSqlQueryModel();
    model7 -> setQuery("SELECT (SELECT NazvDogo FROM RecDogo WHERE NomerDogovor_smeta = NomerDogovor), NomerChek, VidelenoDeneg, StoimostMat, Zarplata, Bonus FROM Smeta");

    model7->setHeaderData(0, Qt::Horizontal, "Название договора");
    model7->setHeaderData(1, Qt::Horizontal, "Номер чека");
    model7->setHeaderData(2, Qt::Horizontal, "Аванс");
    model7->setHeaderData(3, Qt::Horizontal, "Стоимость материалов");
    model7->setHeaderData(4, Qt::Horizontal, "Зарплата");
    model7->setHeaderData(5, Qt::Horizontal, "Бонус");


    ui->tableView->setModel(model7);
    ui->tableView->resizeColumnsToContents();
    ui->tableView->show();
}


void addSmeta::on_tableView_clicked(const QModelIndex &index)
{
    int temp_nom;
    temp_nom = ui->tableView->model()->data(ui->tableView->model()->index(index.row(),1)).toInt();

    ui->lineEdit_6->setText(QString::number(temp_nom));

    QSqlQuery*query = new QSqlQuery();
    query->prepare("SELECT VidelenoDeneg, StoimostMat, Zarplata, Bonus FROM Smeta WHERE NomerChek=:NomerChek");
    query->bindValue(":NomerChek", temp_nom);

    if (query->exec())
    {
        query->next();
        ui->lineEdit_2->setText(query->value(0).toString());
        //ui->lineEdit_7->setText(query->value(1).toString());, NomerDogovor_smeta
        ui->lineEdit_3->setText(query->value(1).toString());
        ui->lineEdit_4->setText(query->value(2).toString());
        ui->lineEdit_5->setText(query->value(3).toString());
        //ui->lineEdit->setText(query->value(4).toString()); , (SELECT NazvDogo FROM RecDogo WHERE NomerDogovor_smeta = NomerDogovor)


    }
}


void addSmeta::on_pushButton_3_clicked()
{
    QSqlQuery*query = new QSqlQuery();
    query->prepare("EXEC izm_smeta @nomchek = " + ui->lineEdit_6->text() + ", @vidden = " + ui->lineEdit_2->text() + ", @nomdog_smeta = " + ui->comboBox->itemText(smetcombo) + ", @stmat = " + ui->lineEdit_3->text() + ", @zarp = " + ui->lineEdit_4->text() + ", @bon = " + ui->lineEdit_5->text());
    //ui->lineEdit_6->text()

    query->exec();
    on_pushButton_2_clicked();
}


void addSmeta::on_pushButton_4_clicked()
{
    QSqlQuery*query = new QSqlQuery();
    query->prepare("EXEC delete_smeta @deleteNomerCheck = "+ ui->lineEdit_6->text());

    query->exec();
    on_pushButton_2_clicked();

}


void addSmeta::on_comboBox_currentIndexChanged(int index)
{
    smetcombo = index;
}

