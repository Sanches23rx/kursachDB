#include "login.h"
#include "ui_login.h"

login::login(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::login)
{
    ui->setupUi(this);
    setWindowTitle("Подключение к БД");

    ui->lineEdit->setText("DESKTOP-4R42CK9\\SQLEXPRESS");
    ui->lineEdit_2->setText("test");
    ui->lineEdit_3->setText("sanches");

    ui->lineEdit_4->setEchoMode(QLineEdit::Password);
    mes = new QMessageBox();
}

login::~login()
{
    delete ui;
}

void login::on_pushButton_clicked()
{
    db = QSqlDatabase::addDatabase("QODBC");
    db.setDatabaseName("DRIVER={SQL Server};SERVER="+ui->lineEdit->text()+";DATABASE="+ui->lineEdit_2->text()+";");
    db.setUserName(ui->lineEdit_3->text());
    db.setPassword(ui->lineEdit_4->text());

    if(db.open())
    {
        mes->setText("Успешное соединение");
    }
    else
    {
        mes->setText("Соединение провалено");
    }

    mes->show();
}

