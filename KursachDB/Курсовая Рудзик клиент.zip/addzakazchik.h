#ifndef ADDZAKAZCHIK_H
#define ADDZAKAZCHIK_H

#include <QWidget>
#include <QSqlQuery>
#include <QMessageBox>
#include <QSqlQueryModel>
#include <QSqlTableModel>


namespace Ui {
class addzakazchik;
}

class addzakazchik : public QWidget
{
    Q_OBJECT

public:
    explicit addzakazchik(QWidget *parent = nullptr);
    ~addzakazchik();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_tableView_clicked(const QModelIndex &index);

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

private:
    Ui::addzakazchik *ui;
    QSqlQueryModel*model3;
    QSqlDatabase db;

};

#endif // ADDZAKAZCHIK_H
