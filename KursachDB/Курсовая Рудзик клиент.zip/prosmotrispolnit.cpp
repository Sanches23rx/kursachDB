#include "prosmotrispolnit.h"
#include "ui_prosmotrispolnit.h"

prosmotrIspolnit::prosmotrIspolnit(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::prosmotrIspolnit)
{
    ui->setupUi(this);
}

prosmotrIspolnit::~prosmotrIspolnit()
{
    delete ui;
}


void prosmotrIspolnit::on_pushButton_clicked()
{
    model1 = new QSqlQueryModel();
    model1 -> setQuery ("SELECT NazvDogo, date FROM RecDogo WHERE date = (SELECT MIN(date) FROM RecDogo)");

    model1->setHeaderData(0, Qt::Horizontal, "Название договора");
    model1->setHeaderData(1, Qt::Horizontal, "Дата создания");

    ui->tableView->setModel(model1);
    ui->tableView->resizeColumnsToContents();
    ui->tableView->show();
}

void prosmotrIspolnit::on_pushButton_2_clicked()
{
    model2 = new QSqlQueryModel();
    model2 -> setQuery ("SELECT NazvDogo, date FROM RecDogo WHERE date = (SELECT MAX(date) FROM RecDogo)");

    model2->setHeaderData(0, Qt::Horizontal, "Название договора");
    model2->setHeaderData(1, Qt::Horizontal, "Дата создания");

    ui->tableView->setModel(model2);
    ui->tableView->resizeColumnsToContents();
    ui->tableView->show();
}

