#ifndef ADDZAKAZ_H
#define ADDZAKAZ_H

#include <QWidget>
#include <QSqlQuery>
#include <QMessageBox>
#include <QSqlQueryModel>
#include <QSqlTableModel>

namespace Ui {
class addzakaz;
}

class addzakaz : public QWidget
{
    Q_OBJECT

public:
    explicit addzakaz(QWidget *parent = nullptr);
    ~addzakaz();

    int zakcombo;


private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_tableView_clicked(const QModelIndex &index);

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_comboBox_currentIndexChanged(int index);

private:
    Ui::addzakaz *ui;
    QSqlQueryModel*model2;
    QSqlDatabase db;

};

#endif // ADDZAKAZ_H
