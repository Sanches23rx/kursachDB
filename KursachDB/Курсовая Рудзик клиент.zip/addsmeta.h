#ifndef ADDSMETA_H
#define ADDSMETA_H

#include <QWidget>
#include <QSqlQuery>
#include <QMessageBox>
#include <QSqlTableModel>


namespace Ui {
class addSmeta;
}

class addSmeta : public QWidget
{
    Q_OBJECT

public:
    explicit addSmeta(QWidget *parent = nullptr);
    ~addSmeta();

    int smetcombo;

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_tableView_clicked(const QModelIndex &index);

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_comboBox_currentIndexChanged(int index);

private:
    Ui::addSmeta *ui;
    QSqlDatabase db;
    QSqlQueryModel*model7;

};

#endif // ADDSMETA_H
