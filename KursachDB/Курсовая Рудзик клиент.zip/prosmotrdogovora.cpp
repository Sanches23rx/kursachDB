#include "prosmotrdogovora.h"
#include "ui_prosmotrdogovora.h"

prosmotrdogovora::prosmotrdogovora(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::prosmotrdogovora)
{
    ui->setupUi(this);
}

prosmotrdogovora::~prosmotrdogovora()
{
    delete ui;
}

void prosmotrdogovora::on_pushButton_clicked()
{
    model33 = new QSqlQueryModel();
    model33 -> setQuery("SELECT Naimenovanie, Budjet, NazvDogo, Gorod, (SELECT Name FROM RecZak WHERE ID_zakazchika_Zakaz = ID_zakazchika) FROM zakazi_po_nazv_gorod WHERE NazvDogo = " + ui->lineEdit->text() + ", Gorod = "  + ui->lineEdit_2->text());


    model33->setHeaderData(0, Qt::Horizontal, "Наименование");
    model33->setHeaderData(1, Qt::Horizontal, "Бюджет");
    model33->setHeaderData(2, Qt::Horizontal, "Название договора");
    model33->setHeaderData(3, Qt::Horizontal, "Город подписания");
    model33->setHeaderData(4, Qt::Horizontal, "Имя заказчика");

    ui->tableView->setModel(model33);
    ui->tableView->resizeColumnsToContents();
    ui->tableView->show();
}

//
//
