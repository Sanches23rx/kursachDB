#include "addzakaz.h"
#include "ui_addzakaz.h"

addzakaz::addzakaz(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::addzakaz)
{
    ui->setupUi(this);

    QSqlQuery* query = new QSqlQuery();

    query->exec("SELECT Name FROM RecZak");
    while(query->next())
        {
            ui->comboBox->addItem(query->value(0).toString());
        }
    zakcombo = 0;
}

addzakaz::~addzakaz()
{
    delete ui;
}

void addzakaz::on_pushButton_clicked()
{
    model2 = new QSqlQueryModel();
    model2 -> setQuery("SELECT Naimenovanie, Budjet, (SELECT Name FROM RecZak WHERE ID_zakazchika_Zakaz = ID_zakazchika), ID_zakaza  FROM Zakaz");

    model2->setHeaderData(0, Qt::Horizontal, "Наименование");
    model2->setHeaderData(1, Qt::Horizontal, "Бюджет");
    model2->setHeaderData(2, Qt::Horizontal, "Имя заказчика");
    model2->setHeaderData(3, Qt::Horizontal, "Регистрационный номер");


    ui->tableView->setModel(model2);
    ui->tableView->resizeColumnsToContents();
    ui->tableView->show();
}


void addzakaz::on_pushButton_2_clicked()
{
    QSqlQuery* addZakaz = new QSqlQuery;

    addZakaz->prepare("EXEC add_zakaz @dnz = " + ui->lineEdit_2->text() + ", @dbz = " + ui->lineEdit_3->text() + ", @zz = " + ui->comboBox->itemText(zakcombo));

    QMessageBox* mess = new QMessageBox();

    if (!addZakaz->exec())
    {
        mess->setText("Неправильно заполнен заказ");
        mess->show();
    }
}


void addzakaz::on_tableView_clicked(const QModelIndex &index)
{
    int temp_nom_zakaz;
    temp_nom_zakaz = ui->tableView->model()->data(ui->tableView->model()->index(index.row(),3)).toInt();

    ui->lineEdit->setText(QString::number(temp_nom_zakaz));

    QSqlQuery*query3 = new QSqlQuery();
    query3->prepare("SELECT Naimenovanie, Budjet FROM Zakaz WHERE ID_zakaza=:ID_zakaza");
    query3->bindValue(":ID_zakaza", temp_nom_zakaz);

    if (query3->exec())
    {
        query3->next();
        ui->lineEdit_2->setText(query3->value(0).toString());
        ui->lineEdit_3->setText(query3->value(1).toString());
        //ui->lineEdit_4->setText(query3->value(2).toString()); , (SELECT Name FROM RecZak WHERE ID_zakazchika_Zakaz = ID_zakazchika)
    }

}


void addzakaz::on_pushButton_3_clicked()
{
    QSqlQuery*query3 = new QSqlQuery();
    query3->prepare("EXEC izm_zakaz @idzakaza = " + ui->lineEdit->text() + ", @naimen = " + ui->lineEdit_2->text() + ", @dudj = " + ui->lineEdit_3->text() + ", @idzakazchikazakaz = " + ui->comboBox->itemText(zakcombo));

    query3->exec();
    on_pushButton_clicked();
}


void addzakaz::on_pushButton_4_clicked()
{
    QSqlQuery*query3 = new QSqlQuery();
    query3->prepare("EXEC delete_zakaz @deleteidzakaza = "  + ui->lineEdit->text());

    query3->exec();
    on_pushButton_clicked();
}


void addzakaz::on_comboBox_currentIndexChanged(int index)
{
    zakcombo = index;
}

