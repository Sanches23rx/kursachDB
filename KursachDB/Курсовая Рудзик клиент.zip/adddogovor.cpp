#include "adddogovor.h"
#include "ui_adddogovor.h"

AddDogovor::AddDogovor(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AddDogovor)
{
    ui->setupUi(this);

    QSqlQuery* query = new QSqlQuery();
    query->exec("SELECT Name FROM RecZak");
    while(query->next())
        {
            ui->comboBox->addItem(query->value(0).toString());
        }
    zakcombo = 0;


    QSqlQuery* query1 = new QSqlQuery();
    query1->exec("SELECT Imya FROM RecIspoln");
    while(query1->next())
        {
            ui->comboBox_2->addItem(query1->value(0).toString());
        }
    ispcombo = 0;


    QSqlQuery* query2 = new QSqlQuery();
    query2->exec("SELECT Naimenovanie FROM Zakaz");
    while(query2->next())
        {
            ui->comboBox_3->addItem(query2->value(0).toString());
        }
    zakazcombo = 0;

}

AddDogovor::~AddDogovor()
{
    delete ui;
}

void AddDogovor::on_pushButton_clicked()
{
    QSqlQuery* addDogo = new QSqlQuery;

    addDogo->prepare("EXEC add_dogovor @rdnd = " + ui->lineEdit->text() + ", @rdg = " + ui->lineEdit_2->text() + ", @zz = " + ui->comboBox->itemText(zakcombo) + ", @im = " + ui->comboBox_2->itemText(ispcombo) + ", @dnz = " + ui->comboBox_3->itemText(zakazcombo));

    QMessageBox* mess1 = new QMessageBox();

    if (!addDogo->exec())
    {
        mess1->setText("Неправильно заполнен договор");
        mess1->show();
    }

}


void AddDogovor::on_pushButton_2_clicked()
{
    QSqlQuery* addZakaz = new QSqlQuery;

    addZakaz->prepare("EXEC add_zakaz @dnz = " + ui->comboBox_3->itemText(zakazcombo) + ", @dbz = " + ui->lineEdit_9->text() + ", @zz = " + ui->comboBox->itemText(zakcombo));

    QMessageBox* mess = new QMessageBox();

    if (!addZakaz->exec())
    {
        mess->setText("Неправильно заполнен заказ");
        mess->show();
    }


}


void AddDogovor::on_pushButton_3_clicked()
{
    QSqlQuery* addIsp = new QSqlQuery;

    addIsp->prepare("EXEC add_ispolnit @im = " + ui->comboBox_2->itemText(ispcombo) + ", @ai = " + ui->lineEdit_8->text() + ", @ti = " + ui->lineEdit_11->text());

    QMessageBox* mess2 = new QMessageBox();

    if (!addIsp->exec())
    {
        mess2->setText("Неправильно заполнен исполнитель");
        mess2->show();
    }
}


void AddDogovor::on_pushButton_4_clicked()
{
    QSqlQuery* addZakazchik = new QSqlQuery;

    addZakazchik->prepare("EXEC add_zakazchik @zz = " + ui->comboBox->itemText(zakcombo) + ", @az = " + ui->lineEdit_4->text() + ", @tz = " + ui->lineEdit_7->text());

    QMessageBox* mess3 = new QMessageBox();

    if (!addZakazchik->exec())
    {
        mess3->setText("Неправильно заполнен заказчик");
        mess3->show();
    }
}

void AddDogovor::on_pushButton_13_clicked()
{
    model3 = new QSqlQueryModel();
    model3 -> setQuery("SELECT Name, Adres, phone FROM RecZak");

    //model3->setHeaderData(0, Qt::Horizontal, "ID_Заказчика");
    model3->setHeaderData(0, Qt::Horizontal, "Имя");
    model3->setHeaderData(1, Qt::Horizontal, "Адрес");
    model3->setHeaderData(2, Qt::Horizontal, "Телефон");

    ui->tableView->setModel(model3);
    ui->tableView->resizeColumnsToContents();
    ui->tableView->show();
}


void AddDogovor::on_pushButton_14_clicked()
{
    model1 = new QSqlQueryModel();
    model1 -> setQuery ("SELECT Imya, AdresIsp, PhoneIspoln FROM RecIspoln");

    //model1->setHeaderData(0, Qt::Horizontal, "ID_Исполнителя");
    model1->setHeaderData(0, Qt::Horizontal, "Имя");
    model1->setHeaderData(1, Qt::Horizontal, "Адрес");
    model1->setHeaderData(2, Qt::Horizontal, "Телефон");

    ui->tableView->setModel(model1);
    ui->tableView->resizeColumnsToContents();
    ui->tableView->show();
}


void AddDogovor::on_pushButton_15_clicked()
{
    model2 = new QSqlQueryModel();
    model2 -> setQuery("SELECT Naimenovanie, Budjet, (SELECT Name FROM RecZak WHERE ID_zakazchika_Zakaz = ID_zakazchika) FROM Zakaz");

    //model2->setHeaderData(0, Qt::Horizontal, "ID_Заказа"); ID_zakaza,
    model2->setHeaderData(0, Qt::Horizontal, "Наименование");
    model2->setHeaderData(1, Qt::Horizontal, "Бюджет");
    model2->setHeaderData(2, Qt::Horizontal, "Имя заказчика");

    ui->tableView->setModel(model2);
    ui->tableView->resizeColumnsToContents();
    ui->tableView->show();
}


void AddDogovor::on_pushButton_16_clicked()
{
    model5 = new QSqlQueryModel();
    model5 -> setQuery("SELECT NomerDogovor, NazvDogo, Gorod, (SELECT Name FROM RecZak WHERE ID_zakazchika_dog = ID_zakazchika), (SELECT Imya FROM RecIspoln WHERE ID_Ispolnit_dog = ID_Ispolnit), (SELECT Naimenovanie FROM Zakaz WHERE ID_zakaza_dog = ID_zakaza), date FROM RecDogo");

    model5->setHeaderData(0, Qt::Horizontal, "Номер договора");
    model5->setHeaderData(1, Qt::Horizontal, "Название договора");
    model5->setHeaderData(2, Qt::Horizontal, "Город подписания договора");
    model5->setHeaderData(3, Qt::Horizontal, "Имя заказчика");
    model5->setHeaderData(4, Qt::Horizontal, "Имя исполнителя");
    model5->setHeaderData(5, Qt::Horizontal, "Наименование заказа");
    model5->setHeaderData(6, Qt::Horizontal, "Дата и время создания");



    ui->tableView->setModel(model5);
    ui->tableView->resizeColumnsToContents();
    ui->tableView->show();
}


void AddDogovor::on_tableView_clicked(const QModelIndex &index)
{
    int temp_nom_dog;
    temp_nom_dog = ui->tableView->model()->data(ui->tableView->model()->index(index.row(),0)).toInt();

    ui->lineEdit_14->setText(QString::number(temp_nom_dog));

    QSqlQuery*query4 = new QSqlQuery();
    query4->prepare("SELECT NazvDogo, Gorod FROM RecDogo WHERE NomerDogovor=:NomerDogovor");
    query4->bindValue(":NomerDogovor", temp_nom_dog);

    if (query4->exec())
    {
        query4->next();
        ui->lineEdit->setText(query4->value(0).toString());
        ui->lineEdit_2->setText(query4->value(1).toString());
    }
}

void AddDogovor::on_pushButton_11_clicked()
{
    QSqlQuery*query4 = new QSqlQuery();
    query4->prepare("izm_dogovor @nomerDogovor = " + ui->lineEdit_14->text() + ", @nazvdogo = " + ui->lineEdit->text() +", @gorod = " + ui->lineEdit_2->text() + ", @idzakazchikadogo = " + ui->comboBox->itemText(zakcombo) + ", @idispolnitdogo = " + ui->comboBox_2->itemText(ispcombo) +", @idzakazadogo = " + ui->comboBox_3->itemText(zakazcombo));

    query4->exec();
    on_pushButton_16_clicked();
}


void AddDogovor::on_pushButton_12_clicked()
{
    QSqlQuery*query4 = new QSqlQuery();
    query4->prepare("EXEC delete_dogovor @deleteNomerDogovor = " + ui->lineEdit_14->text());

    query4->exec();
    on_pushButton_16_clicked();
}

void AddDogovor::on_comboBox_currentIndexChanged(int index)
{
    zakcombo = index;
}


void AddDogovor::on_comboBox_2_currentIndexChanged(int index)
{
    ispcombo = index;
}


void AddDogovor::on_comboBox_3_currentIndexChanged(int index)
{
    zakazcombo = index;
}


//ui->lineEdit_10->setText(query4->value(2).toString()); , (SELECT Name FROM RecZak WHERE ID_Zakazchika_dog = ID_zakazchika),
// ui->lineEdit_5->setText(query4->value(3).toString()); (SELECT Imya FROM RecIspoln WHERE ID_Ispolnit_dog = ID_Ispolnit),
// ui->lineEdit_6->setText(query4->value(4).toString());   (SELECT Naimenovanie FROM Zakaz WHERE ID_zakaza_dog = ID_zakaza)
