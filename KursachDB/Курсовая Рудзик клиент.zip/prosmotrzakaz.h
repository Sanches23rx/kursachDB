#ifndef PROSMOTRZAKAZ_H
#define PROSMOTRZAKAZ_H

#include <QWidget>
#include <QtSql>


namespace Ui {
class prosmotrZakaz;
}

class prosmotrZakaz : public QWidget
{
    Q_OBJECT

public:
    explicit prosmotrZakaz(QWidget *parent = nullptr);
    ~prosmotrZakaz();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::prosmotrZakaz *ui;
    QSqlDatabase db;
    QSqlQueryModel*model2;
    QSqlQueryModel*model22;
    QSqlQueryModel*model23;

};

#endif // PROSMOTRZAKAZ_H
