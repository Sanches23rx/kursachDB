#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "login.h"
#include "ui_login.h"
#include "prosmotrzakazchika.h"
#include "ui_mainwindow.h"
#include "prosmotrispolnit.h"
#include "ui_prosmotrispolnit.h"
#include "prosmotrzakaz.h"
#include "ui_prosmotrzakaz.h"
#include "adddogovor.h"
#include "ui_adddogovor.h"
#include "prosmotrdogovor.h"
#include "ui_prosmotrdogovor.h"
#include "prosmotrdogovora.h"
#include "ui_prosmotrdogovora.h"
#include "addsmeta.h"
#include "ui_addsmeta.h"
#include "addzakazchik.h"
#include "ui_addzakazchik.h"
#include "addispolnitel.h"
#include "ui_addispolnitel.h"
#include "addzakaz.h"
#include "ui_addzakaz.h"


#include <QSqlTableModel>
#include <QSqlQueryModel>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

login*logwin;
ProsmotrZakazchika *prosZakazchik;
prosmotrIspolnit*prosIspolnit;
prosmotrZakaz*prosZakaz;
AddDogovor*addDogo;
prosmotrdogovor*prosDogo;
prosmotrdogovora*prosDogov;
AddDogovor*addZakaz;
addSmeta*addSme;
addzakazchik*addzak;
addispolnitel*addisp;
addzakaz*addzaka;



private slots:
void on_actionconnect_to_DB_triggered();

//void on_tableView_activated(const QModelIndex &index);

//void on_pushButton_clicked();

//void on_action_6_triggered();

void on_action_2_triggered();

void on_action_3_triggered();

void on_action_triggered();

void on_action_4_triggered();

void on_action_7_triggered();


void on_action_9_triggered();

void on_action_10_triggered();

void on_action_11_triggered();

void on_action_12_triggered();

private:
    Ui::MainWindow *ui;
    QSqlTableModel*model;
};
#endif // MAINWINDOW_H
