#include "prosmotrdogovor.h"
#include "ui_prosmotrdogovor.h"

prosmotrdogovor::prosmotrdogovor(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::prosmotrdogovor)
{
    ui->setupUi(this);
    setWindowTitle("Договоры");
}

prosmotrdogovor::~prosmotrdogovor()
{
    delete ui;
}

void prosmotrdogovor::on_pushButton_clicked() //вывод всей таблицы
{
    model5 = new QSqlQueryModel();
    model5 -> setQuery("SELECT NazvDogo, Gorod, (SELECT Name FROM RecZak WHERE ID_zakazchika_dog = ID_zakazchika), (SELECT Imya FROM RecIspoln WHERE ID_Ispolnit_dog = ID_Ispolnit), (SELECT Naimenovanie FROM Zakaz WHERE ID_zakaza_dog = ID_zakaza), date FROM RecDogo");

    //model5->setHeaderData(0, Qt::Horizontal, "Номер договора");
    model5->setHeaderData(0, Qt::Horizontal, "Название договора");
    model5->setHeaderData(1, Qt::Horizontal, "Город подписания договора");
    model5->setHeaderData(2, Qt::Horizontal, "Имя заказчика");
    model5->setHeaderData(3, Qt::Horizontal, "Имя исполнителя");
    model5->setHeaderData(4, Qt::Horizontal, "Наименование заказа");
    model5->setHeaderData(5, Qt::Horizontal, "Дата и время создания");



    ui->tableView->setModel(model5);
    ui->tableView->resizeColumnsToContents();
    ui->tableView->show();
}


void prosmotrdogovor::on_pushButton_2_clicked() //вывод где бонус больше вводимой суммы
{
    model51 = new QSqlQueryModel();
    model51 -> setQuery("EXEC where_bonus_more @d = " + ui->lineEdit->text());


   // model51->setHeaderData(0, Qt::Horizontal, "Номер договора");
    model51->setHeaderData(0, Qt::Horizontal, "Название договора");
    model51->setHeaderData(1, Qt::Horizontal, "Бонус");


    ui->tableView->setModel(model51);
    ui->tableView->resizeColumnsToContents();
    ui->tableView->show();
}


void prosmotrdogovor::on_pushButton_3_clicked() //вывод договора с одинак авансом и стоим.матер. выше вводим суммы
{
    model52 = new QSqlQueryModel();
    model52 -> setQuery("EXEC dogovori_s_odinak_avansom @o = " + ui->lineEdit_2->text() + ", @y = " + ui->lineEdit_3->text());


    model52->setHeaderData(0, Qt::Horizontal, "Название договора");
    model52->setHeaderData(1, Qt::Horizontal, "Наименование заказа");


    ui->tableView->setModel(model52);
    ui->tableView->resizeColumnsToContents();
    ui->tableView->show();
}


void prosmotrdogovor::on_pushButton_4_clicked()
{
    model53 = new QSqlQueryModel();
    model53 -> setQuery("EXEC get_kolichestvo_dogovorov");


    model53->setHeaderData(0, Qt::Horizontal, "Количество договоров");
    model53->setHeaderData(1, Qt::Horizontal, "Количество заказов");


    ui->tableView->setModel(model53);
    ui->tableView->resizeColumnsToContents();
    ui->tableView->show();
}

