#ifndef PROSMOTRDOGOVORA_H
#define PROSMOTRDOGOVORA_H

#include <QWidget>
#include <QtSql>

namespace Ui {
class prosmotrdogovora;
}

class prosmotrdogovora : public QWidget
{
    Q_OBJECT

public:
    explicit prosmotrdogovora(QWidget *parent = nullptr);
    ~prosmotrdogovora();

private slots:
    void on_pushButton_clicked();

private:
    Ui::prosmotrdogovora *ui;
    QSqlDatabase db;
    QSqlQueryModel*model33;

};

#endif // PROSMOTRDOGOVORA_H
