#ifndef PROSMOTRZAKAZCHIKA_H
#define PROSMOTRZAKAZCHIKA_H

#include <QWidget>
#include <QtSql>

namespace Ui {
class ProsmotrZakazchika;
}

class ProsmotrZakazchika : public QWidget
{
    Q_OBJECT

public:
    explicit ProsmotrZakazchika(QWidget *parent = nullptr);
    ~ProsmotrZakazchika();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

private:
    Ui::ProsmotrZakazchika *ui;
    QSqlDatabase db;
    QSqlQueryModel*model3;
    QSqlQueryModel*model31;
    QSqlQueryModel*model32;


};

#endif // PROSMOTRZAKAZCHIKA_H
