#include "addzakazchik.h"
#include "ui_addzakazchik.h"

addzakazchik::addzakazchik(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::addzakazchik)
{
    ui->setupUi(this);
}

addzakazchik::~addzakazchik()
{
    delete ui;
}

void addzakazchik::on_pushButton_clicked()
{
    model3 = new QSqlQueryModel();
    model3 -> setQuery("SELECT Name, Adres, phone, ID_zakazchika FROM RecZak");

    model3->setHeaderData(0, Qt::Horizontal, "Имя");
    model3->setHeaderData(1, Qt::Horizontal, "Адрес");
    model3->setHeaderData(2, Qt::Horizontal, "Телефон");
    model3->setHeaderData(3, Qt::Horizontal, "Табельный номер");


    ui->tableView->setModel(model3);
    ui->tableView->resizeColumnsToContents();
    ui->tableView->show();
}


void addzakazchik::on_pushButton_2_clicked()
{
    QSqlQuery* addZakazchik = new QSqlQuery;

    addZakazchik->prepare("EXEC add_zakazchik @zz = " + ui->lineEdit_2->text() + ", @az = " + ui->lineEdit_3->text() + ", @tz = " + ui->lineEdit_4->text());

    QMessageBox* mess3 = new QMessageBox();

    if (!addZakazchik->exec())
    {
        mess3->setText("Неправильно заполнен заказчик");
        mess3->show();
    }
}


void addzakazchik::on_tableView_clicked(const QModelIndex &index)
{
    int temp_nom_zakazchik;
    temp_nom_zakazchik = ui->tableView->model()->data(ui->tableView->model()->index(index.row(),3)).toInt();

    ui->lineEdit->setText(QString::number(temp_nom_zakazchik));

    QSqlQuery*query1 = new QSqlQuery();
    query1->prepare("SELECT Name, Adres, phone FROM RecZak WHERE ID_zakazchika=:ID_zakazchika");
    query1->bindValue(":ID_zakazchika", temp_nom_zakazchik); //ID_zakazchika=:ID_zakazchika

    if (query1->exec())
    {
        query1->next();
        ui->lineEdit_2->setText(query1->value(0).toString());
        ui->lineEdit_3->setText(query1->value(1).toString());
        ui->lineEdit_4->setText(query1->value(2).toString());
    }

}


void addzakazchik::on_pushButton_3_clicked()
{
    QSqlQuery*query1 = new QSqlQuery();
    query1->prepare("EXEC izm_zakazchik @id_zakazchika = " + ui->lineEdit->text() + ", @nam_zakazchik = " + ui->lineEdit_2->text() + ", @adr_zakazchik = " + ui->lineEdit_3->text() +", @phone_zakazchik = " + ui->lineEdit_4->text());

    query1->exec();
    on_pushButton_clicked();
}


void addzakazchik::on_pushButton_4_clicked()
{
    QSqlQuery*query1 = new QSqlQuery();
    query1->prepare("EXEC delete_zakazchik @deleteidzakazchik = " + ui->lineEdit->text());

    query1->exec();
    on_pushButton_clicked();
}

