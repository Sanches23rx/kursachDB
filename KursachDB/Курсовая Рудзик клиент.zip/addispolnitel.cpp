#include "addispolnitel.h"
#include "ui_addispolnitel.h"

addispolnitel::addispolnitel(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::addispolnitel)
{
    ui->setupUi(this);
}

addispolnitel::~addispolnitel()
{
    delete ui;
}

void addispolnitel::on_pushButton_clicked()
{
    model1 = new QSqlQueryModel();
    model1 -> setQuery ("SELECT Imya, AdresIsp, PhoneIspoln, ID_Ispolnit FROM RecIspoln");

    model1->setHeaderData(0, Qt::Horizontal, "Имя");
    model1->setHeaderData(1, Qt::Horizontal, "Адрес");
    model1->setHeaderData(2, Qt::Horizontal, "Телефон");
    model1->setHeaderData(3, Qt::Horizontal, "Табельный номер");

    ui->tableView->setModel(model1);
    ui->tableView->resizeColumnsToContents();
    ui->tableView->show();
}


void addispolnitel::on_pushButton_2_clicked()
{
    QSqlQuery* addIsp = new QSqlQuery;

    addIsp->prepare("EXEC add_ispolnit @im = " + ui->lineEdit_2->text() + ", @ai = " + ui->lineEdit_3->text() + ", @ti = " + ui->lineEdit_4->text());

    QMessageBox* mess2 = new QMessageBox();

    if (!addIsp->exec())
    {
        mess2->setText("Неправильно заполнен исполнитель");
        mess2->show();
    }
}


void addispolnitel::on_tableView_clicked(const QModelIndex &index)
{
    int temp_nom_isp;
    temp_nom_isp = ui->tableView->model()->data(ui->tableView->model()->index(index.row(),3)).toInt();

    ui->lineEdit->setText(QString::number(temp_nom_isp));

    QSqlQuery*query2 = new QSqlQuery();
    query2->prepare("SELECT Imya, AdresIsp, PhoneIspoln FROM RecIspoln WHERE ID_Ispolnit=:ID_Ispolnit");
    query2->bindValue(":ID_Ispolnit", temp_nom_isp);

    if (query2->exec())
    {
        query2->next();
        ui->lineEdit_2->setText(query2->value(0).toString());
        ui->lineEdit_3->setText(query2->value(1).toString());
        ui->lineEdit_4->setText(query2->value(2).toString());
    }


}


void addispolnitel::on_pushButton_3_clicked()
{
    QSqlQuery*query2 = new QSqlQuery();
    query2->prepare("EXEC izm_ispolnitel @id_ispolnitel = " + ui->lineEdit->text() + ", @imya = " + ui->lineEdit_2->text() + ", @adr_isp = " + ui->lineEdit_3->text() + ", @phone_ispolnit = " + ui->lineEdit_4->text());

    query2->exec();
    on_pushButton_clicked();
}


void addispolnitel::on_pushButton_4_clicked()
{
    QSqlQuery*query2 = new QSqlQuery();
    query2->prepare("EXEC delete_ispolnitel @deleteisp = " + ui->lineEdit->text());

    query2->exec();
    on_pushButton_clicked();
}

