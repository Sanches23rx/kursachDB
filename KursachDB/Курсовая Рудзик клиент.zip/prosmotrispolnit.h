#ifndef PROSMOTRISPOLNIT_H
#define PROSMOTRISPOLNIT_H

#include <QWidget>
#include <QtSql>

namespace Ui {
class prosmotrIspolnit;
}

class prosmotrIspolnit : public QWidget
{
    Q_OBJECT

public:
    explicit prosmotrIspolnit(QWidget *parent = nullptr);
    ~prosmotrIspolnit();

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

private:
    Ui::prosmotrIspolnit *ui;
    QSqlDatabase db;
    QSqlQueryModel*model1;
    QSqlQueryModel*model2;


};

#endif // PROSMOTRISPOLNIT_H
